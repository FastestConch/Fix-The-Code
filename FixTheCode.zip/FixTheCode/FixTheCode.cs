﻿using System;
using System.Threading;

class Program
{
    /*Oh no! My text based game has broken code!
    Using the "Problems" tab in Visual Studios Code and the information taught in lesson 1, try and find and fix all the errors!*/
    static void Main(string[] args)
    {
        Console.Title = "FixTheCode";
        Console.ForegroundColor = ConsoleColor.Green;
        Console.WriteLine(@"
 _______  __  ___   ___    .___________. __    __   _______      ______   ______    _______   _______ 
|   ____||  | \  \ /  /    |           ||  |  |  | |   ____|    /      | /  __  \  |       \ |   ____|
|  |__   |  |  \  V  /     `---|  |----`|  |__|  | |  |__      |  ,----'|  |  |  | |  .--.  ||  |__   
|   __|  |  |   >   <          |  |     |   __   | |   __|     |  |     |  |  |  | |  |  |  ||   __|  
|  |     |  |  /  .  \         |  |     |  |  |  | |  |____    |  `----.|  `--'  | |  '--'  ||  |____ 
|__|     |__| /__/ \__\        |__|     |__|  |__| |_______|    \______| \______/  |_______/ |_______|
                                                                                                                                                                 
");
        Console.ResetColor();
        Console.WriteLine("Welcome to the Forest Adventure!");
        Console.WriteLine("You find yourself at the entrance of a mysterious forest. What will you do?");
        StartGame();
    }

    static void StartGame()
    {
        /*There is a mistake somwehere in this method, can you find it?*/
        Console.WriteLine("1. Enter the forest");
        Console.WriteLine(2. Walk away);
        Console.Write("Choose an option (1 or 2):");
        string choice = Console.ReadLine();

        if (choice == "1")
        {
            EnterForest();
        }
        else if (choice == "2")
        {
            WalkAway();
        }
        else
        {
            Console.WriteLine("Invalid choice. Please try again.");
            StartGame();
        }
    }

    static void EnterForest()
    {
        /*There are two mistakes somewhere in this method, can you find them?*/
        Console.Clear();
        Console.ForegroundColor = ConsoleColor.DarkGreen;
        Console.WriteLine("You step into the forest and feel the cool breeze on your face. You hear rustling in the bushes.");
        Console.ResetColor();
        Console.WriteLine("1. Investigate the bushes");
        Console.WriteLine("2. Keep walking");
        Console.Write("Choose an option (1 or 2):")
        string choice = Console.ReadLine();

        if (choice == "1")
        {
            InvestigateBushes();
        }
        else if (choice == "2")
        {
            KeepWalking();
        }
        else if
        {
            Console.Write("Invalid choice. Please try again.");
            EnterForest();
        }
    }

    static void WalkAway()
    {
        Console.Clear();
        Console.ForegroundColor = ConsoleColor.Yellow;
        Console.WriteLine("You decide not to enter the forest and walk away. Maybe another adventure awaits you elsewhere.");
        Console.ResetColor();
        EndGame();
    }

    static void InvestigateBushes()
    {
        /*There are three mistakes somewhere in this method, can you find them?*/
        Console.Clear();
        Console.ForegroundColor = ConsoleColor.Cyan;
        Console.WriteLine("You cautiously approach the bushes and find a small, friendly fox. It looks at you curiously.");
        Console.ResetColor();
        Console.Write("1. Pet the fox");
        Console.WriteLine("2. Ignore the fox and keep walking");
        Console.Write("Choose an option (1 or 2):");
        string choice = Console.WriteLine();

        if (choice == "1")
        {
            PetFox();
        }
        else (choice == "2")
        {
            KeepWalking();
        }
        else
        {
            Console.WriteLine("Invalid choice. Please try again.");
            InvestigateBushes();
        }
    }

    static void KeepWalking()
    {
        /*There is a mistake somwehere in this method, can you find it?*/
        Console.Clear();
        Console.ForegroundColor = ConsoleColor.Magenta
        Console.WriteLine("You keep walking and find a beautiful clearing with flowers and a small pond. You feel at peace.");
        Console.ResetColor();
        EndGame();
    }

    static void PetFox()
    {
        /*There is a mistake somwehere in this method, can you find it?*/
        Console.Clear();
        Console.ForegroundColor = ConsoleColor.Red;
        Console.WriteLine"You pet the fox and it happily wags its tail. It seems to like you. You have made a new friend!";
        Console.ResetColor();
        EndGame();
    }

    static void EndGame()
    {
        Console.WriteLine("Thank you for playing Forest Adventure!");
        Console.WriteLine("Press any key to exit...");
        Console.ReadKey();
    }
}
